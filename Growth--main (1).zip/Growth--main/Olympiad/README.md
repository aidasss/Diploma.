# myWEBSITE

You find a math problem in a book, or maybe on a contest, or maybe your teacher tells you the problem. You work on it for a half-hour. Then another half-hour. It bugs you and bugs you because you know that other kid who wins all the trophies knows how to do the problem. You want to win the trophies, too, but that's not why you spend another half-hour on the problem. You want to know the answer. More than just the answer, you want to know how to do the problem.

https://abzh00.github.io/myWEBSITE/

![Alt text](https://github.com/abzh00/myWEBSITE/blob/master/captures/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA.PNG?raw=true "Optional Title")

![Alt text](https://github.com/abzh00/myWEBSITE/blob/master/captures/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA1.PNG?raw=true "Optional Title")

![Alt text](https://github.com/abzh00/myWEBSITE/blob/master/captures/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA2.PNG?raw=true "Optional Title")

![Alt text](https://github.com/abzh00/myWEBSITE/blob/master/captures/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA3.PNG?raw=true "Optional Title")
